package com.example.emprendRed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmprendRedApplicationTests {

	@Test
	void contextLoads() {
	}

}
